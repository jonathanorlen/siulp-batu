       <!--/ Application Content -->
       
        <!-- ============================================
        ============== Vendor JavaScripts ===============
        ============================================= -->
       
        
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/bootstrap/bootstrap.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/jRespond/jRespond.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/sparkline/jquery.sparkline.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/slimscroll/jquery.slimscroll.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/animsition/js/jquery.animsition.min.js'?>"></script>
        <!--/ vendor javascripts -->
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/screenfull/screenfull.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/datatables/js/jquery.dataTables.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/datatables/extensions/ColReorder/js/dataTables.colReorder.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/datatables/extensions/Responsive/js/dataTables.responsive.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/datatables/extensions/ColVis/js/dataTables.colVis.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/datatables/extensions/TableTools/js/dataTables.tableTools.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/datatables/extensions/dataTables.bootstrap.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/classie/classie.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/screenfull/screenfull.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/fullcalendar/lib/moment.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/fullcalendar/lib/jquery-ui.custom.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/fullcalendar/fullcalendar.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/flot/jquery.flot.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/flot/jquery.flot.resize.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/flot/jquery.flot.orderBars.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/flot/jquery.flot.stack.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/flot/jquery.flot.pie.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/flot-spline/jquery.flot.spline.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/flot-tooltip/jquery.flot.tooltip.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/gaugejs/gauge.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/raphael/raphael-min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/d3/d3.v2.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/rickshaw/rickshaw.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/morris/morris.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/easypiechart/jquery.easypiechart.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/countTo/jquery.countTo.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/slider/bootstrap-slider.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/colorpicker/js/bootstrap-colorpicker.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/touchspin/jquery.bootstrap-touchspin.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/daterangepicker/moment.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/datetimepicker/js/bootstrap-datetimepicker.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/chosen/chosen.jquery.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/filestyle/bootstrap-filestyle.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/summernote/summernote.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/filestyle/bootstrap-filestyle.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/cropper/cropper.min.js'?>"></script>
        <!-- The jQuery UI widget factory, can be omitted if jQuery UI is already included -->
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/file-upload/js/vendor/jquery.ui.widget.js'?>"></script>
        <!-- The Templates plugin is included to render the upload/download listings -->
        <script src="//blueimp.github.io/JavaScript-Templates/js/tmpl.min.js"></script>
        <!-- The Load Image plugin is included for the preview images and image resizing functionality -->
        <script src="//blueimp.github.io/JavaScript-Load-Image/js/load-image.all.min.js"></script>
        <!-- The Canvas to Blob plugin is included for image resizing functionality -->
        <script src="//blueimp.github.io/JavaScript-Canvas-to-Blob/js/canvas-to-blob.min.js"></script>
        <!-- blueimp Gallery script -->
        <script src="//blueimp.github.io/Gallery/js/jquery.blueimp-gallery.min.js"></script>
        <!-- The Iframe Transport is required for browsers without support for XHR file uploads -->
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/file-upload/js/jquery.iframe-transport.js'?>"></script>
        <!-- The basic File Upload plugin -->
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/file-upload/js/jquery.fileupload.js'?>"></script>
        <!-- The File Upload processing plugin -->
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/file-upload/js/jquery.fileupload-process.js'?>"></script>
        <!-- The File Upload image preview & resize plugin -->
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/file-upload/js/jquery.fileupload-image.js'?>"></script>
        <!-- The File Upload audio preview plugin -->
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/file-upload/js/jquery.fileupload-audio.js'?>"></script>
        <!-- The File Upload video preview plugin -->
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/file-upload/js/jquery.fileupload-video.js'?>"></script>
        <!-- The File Upload validation plugin -->
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/file-upload/js/jquery.fileupload-validate.js'?>"></script>
        <!-- The File Upload user interface plugin -->
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/file-upload/js/jquery.fileupload-ui.js'?>"></script>
        <script src="<?php echo base_url().'component/admin/assets/js/vendor/parsley/parsley.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/magnific-popup/jquery.magnific-popup.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/mixitup/jquery.mixitup.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/chosen/chosen.jquery.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/summernote/summernote.min.js'?>"></script>
        <!--/ vendor javascripts -->
        <script type="text/javascript" src="//maps.google.com/maps/api/js?sensor=true"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/gmaps/gmaps.js'?>"></script>
        <!--/ vendor javascripts -->
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/jqvmap/jquery.vmap.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/jqvmap/maps/jquery.vmap.world.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/jqvmap/maps/jquery.vmap.usa.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/jqvmap/maps/jquery.vmap.europe.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/jqvmap/maps/jquery.vmap.germany.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/jqvmap/data/jquery.vmap.sampledata.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/filestyle/bootstrap-filestyle.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/daterangepicker/moment.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/slider/bootstrap-slider.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/datatables/js/jquery.dataTables.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/datatables/extensions/dataTables.bootstrap.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/datatables/extensions/Pagination/input.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/date-format/jquery-dateFormat.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/touchspin/jquery.bootstrap-touchspin.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/footable/footable.all.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/toastr/toastr.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/countTo/jquery.countTo.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/raty-fa/jquery.raty-fa.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/typeahead/typeahead.bundle.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/handlebars/handlebars-v3.0.3.js'?>"></script>
        <!--/ vendor javascripts -->
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/nestable/jquery.nestable.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/jquery-ui/jquery-ui.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/jstree/jstree.min.js'?>"></script>
        <!-- <script src="https://google-code-prettify.googlecode.com/svn/loader/run_prettify.js?skin=sons-of-obsidian"></script> -->
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/owl-carousel/owl.carousel.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/daterangepicker/moment.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/datetimepicker/js/bootstrap-datetimepicker.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/chosen/chosen.jquery.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/summernote/summernote.min.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/coolclock/coolclock.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/vendor/coolclock/excanvas.js'?>"></script>
        <script src="<?php echo base_url(). 'component/admin/assets/js/main.js'?>"></script>
         <script src="<?php echo base_url(). 'component/admin/'?>assets/js/vendor/modernizr/modernizr-2.8.3-respond-1.4.2.min.js"></script>
        


    </body>
    </html>
        