<script src="<?php echo base_url() . 'component/web/js/responsiveslides.min.js '?>"></script>
<script>
    $(function () {
      $("#slider").responsiveSlides({
      	auto: false,
      	nav: false,
      	speed: 500,
        namespace: "callbacks",
        pager: true,
      });
    });
	
</script>
	<div class="header-slider">
		<div class="slider">
			<div class="callbacks_container">
			  <ul class="rslides" id="slider">
				<div class="slid banner1">				  
				  <div class="caption">
					<h3>Donec ut turpis sit amet enim mattis commodo velit.</h3>
					<p>FOURNIER Timber carefully selects from a wide range of quality hardwoods to customers exact requirements which minimises wastage.</p>
					<a class="hvr-bounce-to-right btn-left" href="#">Click</a>	
					<a class="hvr-bounce-to-left  btn-right" href="#">learn more</a>
					</div>
				</div>
				<div class="slid banner2">				  
				  <div class="caption">
					<h3>Donec ut turpis sit amet enim mattis commodo velit.</h3>
					<p>FOURNIER Timber carefully selects from a wide range of quality hardwoods to customers exact requirements which minimises wastage.</p>
					<a class="hvr-bounce-to-right btn-left" href="#">Click</a>	
					<a class="hvr-bounce-to-left  btn-right" href="#">learn more</a>
					</div>
				</div>
				<div class="slid banner3">				  
				  <div class="caption">
					<h3>Donec ut turpis sit amet enim mattis commodo velit.</h3>
					<p>FOURNIER Timber carefully selects from a wide range of quality hardwoods to customers exact requirements which minimises wastage.</p>
					<a class="hvr-bounce-to-right btn-left" href="#">Click</a>	
					<a class="hvr-bounce-to-left  btn-right" href="#">learn more</a>
					</div>
				</div>
			</ul>
		  </div>
	  </div>
</div>	 
<!---->