<div class="content-wrapper" style="min-height: 916px;">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Technical Support      
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Technical Support</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <!-- /.box -->

        <div class="box">          
          <div class="box-body">
           <div class="sukses" ></div>
           <div class="box-footer clearfix">
          </div>
           <h4 class="block">Alamat Developer</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <address>
                                <strong>Cloud Astro</strong><br />
                               Jl. Besar ijen 82<br />
                                Malang, Jawa Timur<br />
                                <!-- <i class="icon-phone"></i> (0341) 452789 -->
                            </address>
                        </div>
                        <div class="col-md-6">
                            <address>
                                <strong>Kontak</strong><br />
                                <i class="icon-phone"></i> 085100588901<br/>
                                <a href="mailto:#">cloudastro.id@gmail.com</a><br/>
                                <a href="http://www.cloud-astro.com">cloud-astro.com</a>
                            </address>
                        </div>
         </div><!-- /.box-body -->      

       </div><!-- /.box -->
     </div><!-- /.col -->
   </div><!-- /.row -->
 </section><!-- /.content -->
</div>
