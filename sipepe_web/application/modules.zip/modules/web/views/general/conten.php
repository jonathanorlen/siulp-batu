<section id="content" class="container-fluid">
	<div class="container">
		<div class="row">
			<div class="span12">
				<h1>Selamat Datang di Web Kami</h1>
				<span class="purchase" style="text-align:justify;padding-left:50px;padding-right:50px"> <br> Kami adalah perusahaan yang bergerak dibidang jasa Konsultasi Kami adalah perusahaan yang bergerak dibidang jasa Konsultasi Kami adalah perusahaan yang bergerak dibidang jasa Konsultasi Kami adalah perusahaan yang bergerak dibidang jasa Konsultasi Kami adalah perusahaan yang bergerak dibidang jasa Konsultasi Kami adalah perusahaan yang bergerak dibidang jasa Konsultasi Kami adalah perusahaan yang bergerak dibidang jasa Konsultasi Kami adalah perusahaan yang bergerak dibidang jasa Konsultasi Kami adalah perusahaan yang bergerak dibidang jasa Konsultasi Kami adalah perusahaan yang bergerak dibidang jasa Konsultasi Kami adalah perusahaan yang bergerak dibidang jasa Konsultasi Kami adalah perusahaan yang bergerak dibidang jasa Konsultasi </span>
			</div>
			<!-- <div class="span3 aligncenter"><a href="#" class="button large red">Purchase Now</a></div> -->
		</div>
		
		<div class="row">
			<div class="span12">
				<div class="title"><h2>Layanan Kami</h2></div>
				<div class="row">
					<div class="span3">
						<a href="#" class="link-block">
							<span class="move-item icon-2 move-bg-icon"></span>
							<h2 class="move-item">01 Konsultan Bisnis</h2>
							<p class="move-item">In convallis venenatis magna, nec interdum ipsum iaculis et. Nulla facilisi. Duis in neque malesuada vestibulum ut neque. </p>
						</a>
					</div>
					<div class="span3">
						<a href="#" class="link-block">
							<span class="move-item icon-5 move-bg-icon"></span>
							<h2 class="move-item">02 Konsultan IT</h2>
							<p class="move-item">In convallis venenatis magna, nec interdum ipsum iaculis et. Nulla facilisi. Duis in neque malesuada vestibulum ut neque. </p>
						</a>
					</div>
					<div class="span3">
						<a href="#" class="link-block">
							<span class="move-item icon-1 move-bg-icon"></span>
							<h2 class="move-item">03 Konsultan Pajak</h2>
							<p class="move-item">In convallis venenatis magna, nec interdum ipsum iaculis et. Nulla facilisi. Duis in neque malesuada vestibulum ut neque. </p>
						</a>
					</div>
					<div class="span3">
						<a href="#" class="link-block">
							<span class="move-item icon-3 move-bg-icon"></span>
							<h2 class="move-item">04 Konsultan Keuangan</h2>
							<p class="move-item">In convallis venenatis magna, nec interdum ipsum iaculis et. Nulla facilisi. Duis in neque malesuada vestibulum ut neque. </p>
						</a>
					</div>
					<div class="span3">
						<a href="#" class="link-block">
							<span class="move-item icon-4 move-bg-icon"></span>
							<h2 class="move-item">05 Konsultan Interior</h2>
							<p class="move-item">In convallis venenatis magna, nec interdum ipsum iaculis et. Nulla facilisi. Duis in neque malesuada vestibulum ut neque. </p>
						</a>
					</div>
					<div class="span3">
						<a href="#" class="link-block">
							<span class="move-item icon-6 move-bg-icon"></span>
							<h2 class="move-item">06 Konsultan Pengairan</h2>
							<p class="move-item">In convallis venenatis magna, nec interdum ipsum iaculis et. Nulla facilisi. Duis in neque malesuada vestibulum ut neque. </p>
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	</section>