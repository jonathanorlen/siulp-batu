<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body onload="window.print()">
	<br>
	<h4 style="text-align:center">TANDA TERIMA HONORARIUM</h4>
	<h4 style="text-align:center;margin-top:-12px;">POKJA(KELOMPOK POKJA) BAGIAN LAYANAN PENGADAAN</h4>
	<h4 style="text-align:center;margin-top:-12px;">PAKET PEKERJAAN </h4>

	<p style="float:right;">Kode Rekening :4563798284234</p>
	<table border="1" style="border-collapse: collapse;width:100%;margin-top:-">
		<thead>
			<th>No</th>
			<th>NAMA/NIP</th>
			<th>JABATAN<br>DALAM POKJA</th>
			<th>TGL/NO.SK</th>
			<th>HONOR/<br>PAKET(RP)</th>
			<th>PPH 21<BR>5%(Rp)</th>
			<th>JUMLAH<br>DITERIMA</th>
			<th colspan="2">TANDA TANGAN</th>
		</thead>
		<tbody>
			<td>1</td>
			<td>
				<P>
					Alex Wahyu Kesuma, ST, MT  <br>
					NIP : 23456789172112 1 008 <br>
					NPWP: 12.32312.3144.54523  <br>
				</P>
			</td>
			<td>
				<p>Ketua</p>
			</td>
			<td style="text-align: center;" rowspan="3">
				bla bla bla bla bla bla bla bla bla
			</td>
			<td>
				<p>800.000</p>
			</td>
			<td>
				<p>4000</p>
			</td>
			<td>
				<p>760.000</p>
			</td>
			<td>
				<p>1</p>
			</td>
			<td>
				<p>2</p>
			</td>

		</tbody>
		<tfoot>
			<td colspan="3">Jumlah</td>
			<td></td>
			<td>1.500.000</td>
			<td>1.500.000</td>
			<td>1.500.000</td>
			<td colspan="2"></td>
		</tfoot>
	</table>
	<br>
	<tr>
		<th>
			<P style="margin-left:20px;">Kategori</P>
		</th>
		<th>
			<p style="margin-left:90px;margin-top:-35px; "><span>:</span>&nbsp Barang</p>
			<p style="margin-left:90px;margin-top:-10px;"><span>:</span>&nbsp 1.237.000.99</p>
		</th>
	</tr>
	<table style="width: 100%;">
		<tr>
			<th>
				<p style="text-align:center;">Setuju dibayar</p>
				<p style="text-align:center;margin-top:-10px;">Pengguna Anggaran</p>
			</th>
			<th>
				<p style="text-align:center;">Menyetujui</p>
				<p style="text-align:center;margin-top:-10px;">Penjabat Pelaksana Teknis Kegiatan</p>	
			</th>
			<th>
				<p style="text-align:center;margin-top:-10px;">Lunas dibayar</p>
				<p style="text-align:center;margin-top:-10px;">Tgl................</p>
				<p style="text-align:center;margin-top:-10px;">Bendahara Pengeluaran</p>
			</th>
		</tr>
		<tr>
			<td>
				<p style="text-align:center;margin-top:30px;" ><b><u>WIDODO,SH,MH</u></b></p>
				<p style="text-align:center;margin-top:-10px;">NIP :1542136213123 1 062</p>
			</td>
			<td>
				<p style="text-align:center;margin-top:30px;" ><b><u>SYEH ZAENAL ARIFIN,ST</u></b></p>
				<p style="text-align:center;margin-top:-10px;">NIP :1542136213123 1 062</p>
			</td>
			<td>
				<p style="text-align:center;margin-top:30px;" ><b><u>RIA SHANTI, SH</u></b></p>
				<p style="text-align:center;margin-top:-10px;">NIP :1542136213123 1 062</p>
			</td>
		</tr>
	</table>
</body>
</html>